from service.environment_fact import predict_mushroom_env
from service.maturity_prediction_abalone import predict_abalone
from service.maturity_prediction_buthan import predict_buthan
from service.maturity_prediction_oyester import predict_oyester


def start_predict(image1 , image2 , mushroom_type):
    env =  predict_mushroom_env(image1)

    if(mushroom_type == "abalone"):
        maturity =  predict_abalone(image2)
    elif(mushroom_type == "button"):
        maturity = predict_buthan(image2)
    elif(mushroom_type == "oyester"):
        maturity = predict_oyester(image2)
    else:
        maturity = {
            "maturity_prediction": "not found"
        }

    return {
        "env" : env,
        "maturity" : maturity
    }