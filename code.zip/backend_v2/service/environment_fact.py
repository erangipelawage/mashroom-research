from keras.applications.nasnet import preprocess_input
from keras.models import load_model
import cv2
import numpy as np


def load_model_P():
    return load_model('models/environmentalfactor.h5', compile=False)
    return model

def resize_image(image_file):
    img = cv2.imdecode(np.frombuffer(image_file.read(), np.uint8), cv2.IMREAD_COLOR)
    img = cv2.resize(img, (224, 224))
    x = np.array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)

    return x

def predict_mushroom_env(image):

    model = load_model_P()
    x = resize_image(image)

    result1 = model.predict(x)
    list1 = result1.tolist()
    finalresult = list1[0]
    max_value = max(finalresult)
    max_index = finalresult.index(max_value)

    if max_index == 0:
        mushroom_type = "dry"
    elif max_index == 1:
        mushroom_type = "wet"

    data = {
        "env" : mushroom_type
    }

    return data