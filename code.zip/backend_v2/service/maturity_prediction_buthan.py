from keras.models import load_model
import numpy as np
import cv2

class_labels = ['Ready to harvest', '1 day more']

def load_model_p():
    return load_model('models/model3/Buthan.h5', compile=False)

def load_and_preprocess_image(image_file, target_size=(224, 224)):
    img = cv2.imdecode(np.frombuffer(image_file.read(), np.uint8), cv2.IMREAD_COLOR)
    img = cv2.resize(img, target_size)
    img_array = img.astype('float32') / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    return img_array

def predict_buthan(image):
    model = load_model_p()
    preprocessed_img = load_and_preprocess_image(image)
    predictions = model.predict(preprocessed_img)
    predicted_class_index = np.argmax(predictions[0])
    predicted_class_label = class_labels[predicted_class_index]

    return {
        "maturity_prediction" : predicted_class_label
    }