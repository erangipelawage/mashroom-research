from flask import Flask, request, jsonify
from service.service import start_predict
import io
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/' , methods=['POST'])
def home():
    if 'image' not in request.files:
        return "No file part", 400

    image = request.files['image']
    image_data = image.read()
    image1 = io.BytesIO(image_data)
    image2 = io.BytesIO(image_data)

    image1.seek(0)
    image2.seek(0)

    if image.filename == '':
        return "No selected file", 400

    mushroom_type = request.form.get('mushroom_type')

    if image:
        final = start_predict(image1 , image2 , mushroom_type)
        return jsonify(final)

# Run the application
if __name__ == '__main__':
    app.run(debug=True , port=5002)
