import './Loading.css'; // Make sure to create this CSS file

function Loading() {
    return (
        <div className="loading-container">
            <img src="https://th.bing.com/th/id/R.ef1a616518907c0bbfa363ddd9ae407c?rik=OjGcZjVvlngghA&riu=http%3a%2f%2fpluspng.com%2fimg-png%2fmushroom-png-mushroom-png-image-42881-5148.png&ehk=lwUEFMxGt%2fzVu%2fshC4Y3y8KSm6rJ8yoUxuwWmL5GJNE%3d&risl=1&pid=ImgRaw&r=0" alt="Loading..." className="loading-image" />
            <div className="spinner-border text-danger" role="status">
                <span className="sr-only">Loading...</span>
            </div>
        </div>
    );
}

export default Loading;
