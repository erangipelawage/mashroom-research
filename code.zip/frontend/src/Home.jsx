import React, { useState } from 'react';
import axios from 'axios';
import './App.css';
import Loading from "./Loading";

function Home() {
    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [uploadedImage, setUploadedImage] = useState(null);
    const [predClass, setPredClass] = useState(null)
    const [typeData, setTypeData] = useState(null)
    const [envData, setEnvData] = useState(null)

    const handleFileChange = (event) => {
        const selectedFile = event.target.files[0];
        setFile(selectedFile);

        // Generate a preview of the selected image
        if (selectedFile) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setUploadedImage(reader.result); // Set the image preview
            };
            reader.readAsDataURL(selectedFile); // Convert file to data URL
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (!file) return;

        setLoading(true);

        const formData = new FormData();
        formData.append('image', file);

        try {
            // First request to upload the image
            const typeResponse = await axios.post('http://127.0.0.1:5000', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            const typeData = typeResponse.data;
            setTypeData(typeData);

            // Append mushroom type for the second request
            formData.append('mushroom_type', typeData.type.toLowerCase());

            // Second request to send image and mushroom type
            const envResponse = await axios.post('http://127.0.0.1:5002', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            const envData = envResponse.data;
            setEnvData(envData);

        } catch (error) {
            console.error('Error uploading file:', error);
        } finally {
            setLoading(false);
        }
    };


    const handleReset = () => {
        setFile(null);
        setUploadedImage(null);
        document.getElementById('exampleFormControlFile1').value = ''; // Reset the file input
        setPredClass(null)
        setTypeData(null)
        setEnvData(null)
    };

    if (loading) {
        return (
            <div className="loading"><Loading /></div>
        );
    }

    return (
        <div className="bg d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
            <div className="card w-50 shadow">
                <div className="card-body text-dark">
                    <h5 className="card-title">Image Identification</h5>

                    {uploadedImage && (
                        <div className="uploaded-image text-center mb-3">
                            <img src={uploadedImage} alt="Uploaded" style={{ maxWidth: '250px', maxHeight: '250px' }} />
                        </div>
                    )}

                    <form onSubmit={handleSubmit}>
                        <div className="form-group">
                            <label htmlFor="exampleFormControlFile1">Upload your image</label>
                            <input
                                type="file"
                                className="form-control-file"
                                id="exampleFormControlFile1"
                                onChange={handleFileChange}
                            />
                        </div>
                        <div className="d-flex justify-content-between">
                            <button type="submit" className="btn btn-primary">Check</button>
                            <button type="button" className="btn btn-secondary" onClick={handleReset}>Reset</button>
                        </div>
                    </form>

                    {typeData && envData && (
                        <div style={{ maxHeight: '50vh', overflowY: 'auto', marginTop: '20px' }}>
                            <table className="table table-sm table-bordered">
                                <thead className="thead-dark">
                                    <tr>
                                        <th scope="col">Property</th>
                                        <th scope="col">Value</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Color</td>
                                        <td>{typeData.color}</td>
                                    </tr>
                                    <tr>
                                        <td>Cultivated</td>
                                        <td>{typeData.cultivated}</td>
                                    </tr>
                                    <tr>
                                        <td>Edible</td>
                                        <td>{typeData.edible}</td>
                                    </tr>
                                    <tr>
                                        <td>Flavor</td>
                                        <td>{typeData.flavor}</td>
                                    </tr>
                                    <tr>
                                        <td>Shape</td>
                                        <td>{typeData.shape}</td>
                                    </tr>
                                    <tr>
                                        <td>Size</td>
                                        <td>{typeData.size}</td>
                                    </tr>
                                    <tr>
                                        <td>Type</td>
                                        <td>{typeData.type}</td>
                                    </tr>
                                    <tr>
                                        <td>Nutrition</td>
                                        <td>
                                            <ul>
                                                {typeData.nutrition.map((item, index) => (
                                                    <li key={index}>{item}</li>
                                                ))}
                                            </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Environment</td>
                                        <td>{envData.env.env}</td>
                                    </tr>
                                    <tr>
                                        <td>Maturity</td>
                                        <td>{envData.maturity.maturity_prediction}</td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );

}

export default Home;
